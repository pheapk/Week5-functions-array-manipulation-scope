let addFive = (num) => {
  num + 5;
};

let divideBy = (x, y) => {
  return x / y;
};

let logToConsole = () => {
  let msg = "MIT Bootcamp";
  console.log(msg);
};
